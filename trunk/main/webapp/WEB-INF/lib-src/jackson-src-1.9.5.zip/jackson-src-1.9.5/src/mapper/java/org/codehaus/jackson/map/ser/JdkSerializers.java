package org.codehaus.jackson.map.ser;

/**
 * @deprecated Since 1.9 use {@link org.codehaus.jackson.map.ser.std.StdJdkSerializers}
 */
@Deprecated
public class JdkSerializers
    extends org.codehaus.jackson.map.ser.std.StdJdkSerializers
{

}
